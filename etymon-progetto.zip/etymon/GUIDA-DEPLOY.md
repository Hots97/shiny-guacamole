# 🚀 Guida al Deploy di Etymon su Vercel

## Cosa ti serve
- Account **GitHub** (gratuito) → github.com
- Account **Vercel** (gratuito) → vercel.com
- **API Key Anthropic** → console.anthropic.com

---

## PASSO 1 — Ottieni la API Key Anthropic

1. Vai su **https://console.anthropic.com**
2. Registrati o accedi
3. Clicca su **"API Keys"** nel menu a sinistra
4. Clicca **"Create Key"**, dagli un nome (es. "Etymon")
5. **Copia la chiave** e salvala in un posto sicuro (la vedrai solo una volta)

---

## PASSO 2 — Carica il progetto su GitHub

1. Vai su **https://github.com** e accedi
2. Clicca il **"+"** in alto a destra → **"New repository"**
3. Nome: `etymon` | Visibilità: **Private** | Clicca **"Create repository"**
4. Nella pagina del repo, clicca **"uploading an existing file"**
5. Trascina dentro **tutti i file e le cartelle** di questo progetto:
   ```
   etymon/
   ├── api/
   │   └── etymology.js
   ├── src/
   │   ├── App.jsx
   │   └── main.jsx
   ├── public/
   │   └── favicon.svg
   ├── index.html
   ├── package.json
   ├── vite.config.js
   ├── vercel.json
   └── .gitignore
   ```
6. Clicca **"Commit changes"**

---

## PASSO 3 — Deploy su Vercel

1. Vai su **https://vercel.com** e clicca **"Sign Up"**
2. Scegli **"Continue with GitHub"** e autorizza
3. Nella dashboard, clicca **"Add New Project"**
4. Trova il repo `etymon` e clicca **"Import"**
5. Lascia tutto di default, clicca **"Deploy"**
6. Aspetta ~1 minuto che finisca il build

---

## PASSO 4 — Aggiungi la API Key (FONDAMENTALE)

Senza questo step l'app non funziona.

1. Nella dashboard Vercel, clicca sul progetto **etymon**
2. Vai su **Settings** → **Environment Variables**
3. Clicca **"Add New"**
4. Compila così:
   - **Name:** `ANTHROPIC_API_KEY`
   - **Value:** incolla la tua chiave (inizia con `sk-ant-...`)
   - **Environment:** spunta tutte e tre (Production, Preview, Development)
5. Clicca **"Save"**
6. Vai su **Deployments** → clicca i tre puntini sull'ultimo deploy → **"Redeploy"**

---

## PASSO 5 — Il tuo sito è online! 🎉

Vercel ti dà un URL tipo:
```
https://etymon-tuonome.vercel.app
```

Aprilo da **iPhone con Safari** → funziona perfettamente come web app.

### Bonus: Aggiungila alla schermata Home iPhone
1. Apri l'URL in **Safari**
2. Tocca l'icona **Condividi** (il quadrato con la freccia)
3. Scorri e tocca **"Aggiungi a schermata Home"**
4. Dai un nome → **"Aggiungi"**

Ora hai l'icona sul tuo iPhone come un'app vera! 📱

---

## Costi

| Servizio | Piano gratuito |
|----------|---------------|
| GitHub | ✅ Illimitato |
| Vercel | ✅ 100GB banda/mese |
| Anthropic API | ~$0.003 per ricerca |

Le prime ricerche costano pochissimo. Puoi impostare un **budget limit** su console.anthropic.com → Billing → Usage limits.

---

## Problemi comuni

**L'app si apre ma la ricerca non funziona**
→ Controlla di aver aggiunto `ANTHROPIC_API_KEY` nelle variabili d'ambiente e di aver fatto il redeploy.

**Errore 404 sull'API**
→ Verifica che il file `api/etymology.js` sia nella cartella giusta su GitHub.

**Build fallita**
→ Controlla che tutti i file siano stati caricati correttamente, in particolare `package.json`.
